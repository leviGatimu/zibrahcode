<?php
require_once __DIR__ . '/../includes/admin-auth-check.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrfVerify()) {
    redirectTo('/admin/contact/index.php');
}

$id = (int) ($_POST['id'] ?? 0);
$status = in_array($_POST['status'] ?? '', ['new', 'read', 'archived'], true) ? $_POST['status'] : 'read';

getDb()->prepare('UPDATE contact_messages SET status = ? WHERE id = ?')->execute([$status, $id]);
redirectTo('/admin/contact/index.php');
