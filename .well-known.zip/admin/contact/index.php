<?php
require_once __DIR__ . '/../includes/admin-auth-check.php';

$messages = getDb()->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll();

$pageTitle = 'Contact Messages | Zibrah Code Admin';
$activeAdminNav = 'contact';
require __DIR__ . '/../includes/admin-header.php';
?>

<h1 class="font-display font-black text-3xl text-brand-black mb-10">Contact Messages</h1>

<div class="space-y-4">
    <?php foreach ($messages as $msg): ?>
        <div class="bg-white border <?php echo $msg['status'] === 'new' ? 'border-brand-gold' : 'border-gray-100'; ?> p-8">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <p class="font-bold text-brand-black"><?php echo e($msg['name']); ?> <span class="font-normal text-gray-400">&lt;<?php echo e($msg['email']); ?>&gt;</span></p>
                    <?php if ($msg['subject']): ?><p class="text-sm text-gray-500 mt-1"><?php echo e($msg['subject']); ?></p><?php endif; ?>
                </div>
                <span class="text-xs text-gray-400"><?php echo date('M j, Y g:i A', strtotime($msg['created_at'])); ?></span>
            </div>
            <p class="text-gray-600 mb-6"><?php echo nl2br(e($msg['message'])); ?></p>
            <div class="flex gap-4">
                <?php if ($msg['status'] !== 'read'): ?>
                    <form action="/admin/contact/update-status" method="POST">
                        <?php echo csrfField(); ?>
                        <input type="hidden" name="id" value="<?php echo $msg['id']; ?>">
                        <input type="hidden" name="status" value="read">
                        <button type="submit" class="text-xs font-bold uppercase text-brand-black hover:text-brand-gold">Mark Read</button>
                    </form>
                <?php endif; ?>
                <?php if ($msg['status'] !== 'archived'): ?>
                    <form action="/admin/contact/update-status" method="POST">
                        <?php echo csrfField(); ?>
                        <input type="hidden" name="id" value="<?php echo $msg['id']; ?>">
                        <input type="hidden" name="status" value="archived">
                        <button type="submit" class="text-xs font-bold uppercase text-gray-500 hover:text-brand-black">Archive</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
    <?php if (empty($messages)): ?>
        <p class="p-10 text-center text-gray-400 italic bg-white border border-gray-100">No messages yet.</p>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>
