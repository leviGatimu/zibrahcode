<?php
require_once __DIR__ . '/../includes/admin-auth-check.php';

$db = getDb();
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$post = null;
if ($id) {
    $stmt = $db->prepare('SELECT * FROM posts WHERE id = ?');
    $stmt->execute([$id]);
    $post = $stmt->fetch();
    if (!$post) {
        flashSet('error', 'Post not found.');
        redirectTo('/admin/posts/index.php');
    }
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfVerify()) {
        $error = 'Invalid form submission, please try again.';
    } else {
        $title = trim($_POST['title'] ?? '');
        $slugInput = trim($_POST['slug'] ?? '');
        $excerpt = trim($_POST['excerpt'] ?? '');
        $body = $_POST['body'] ?? '';
        $category = trim($_POST['category'] ?? '');
        $status = ($_POST['status'] ?? '') === 'published' ? 'published' : 'draft';
        $metaDescription = trim($_POST['meta_description'] ?? '');
        $podcastEpisodeId = ($_POST['podcast_episode_id'] ?? '') !== '' ? (int) $_POST['podcast_episode_id'] : null;

        if ($title === '' || $body === '') {
            $error = 'Title and body are required.';
        } else {
            $slug = uniqueSlug(slugify($slugInput !== '' ? $slugInput : $title), 'posts', $post['id'] ?? null);
            $featuredImagePath = $post['featured_image_path'] ?? null;

            if (!empty($_FILES['featured_image']['name'])) {
                $uploaded = handleImageUpload($_FILES['featured_image'], 'blog/images/' . date('Y/m'), $title);
                if ($uploaded) {
                    $featuredImagePath = $uploaded;
                } else {
                    $error = 'Featured image upload failed — please use a JPG, PNG, or WEBP under 5MB.';
                }
            }

            if (!$error) {
                $publishedAt = $post['published_at'] ?? null;
                $isNewlyPublished = $status === 'published' && ($post['status'] ?? '') !== 'published';
                if ($status === 'published' && !$publishedAt) {
                    $publishedAt = date('Y-m-d H:i:s');
                }

                if ($post) {
                    $stmt = $db->prepare(
                        'UPDATE posts SET title=?, slug=?, excerpt=?, body=?, featured_image_path=?, category=?, podcast_episode_id=?, status=?, published_at=?, meta_description=?, updated_at=NOW() WHERE id=?'
                    );
                    $stmt->execute([$title, $slug, $excerpt, $body, $featuredImagePath, $category, $podcastEpisodeId, $status, $publishedAt, $metaDescription, $post['id']]);
                    flashSet('success', 'Post updated.');
                } else {
                    $stmt = $db->prepare(
                        'INSERT INTO posts (title, slug, excerpt, body, featured_image_path, category, podcast_episode_id, status, published_at, meta_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                    );
                    $stmt->execute([$title, $slug, $excerpt, $body, $featuredImagePath, $category, $podcastEpisodeId, $status, $publishedAt, $metaDescription]);
                    flashSet('success', 'Post created.');
                }

                if ($isNewlyPublished) {
                    $postUrl = rtrim(SITE_URL, '/') . '/post.php?slug=' . urlencode($slug);
                    $imageUrl = $featuredImagePath ? rtrim(SITE_URL, '/') . '/' . $featuredImagePath : null;
                    $html = renderNotificationEmail(
                        'New Post',
                        $title,
                        $excerpt !== '' ? $excerpt : 'A new post is up on Zibrah Code.',
                        $imageUrl,
                        'Read the Post',
                        $postUrl
                    );
                    notifySubscribers('New Post: ' . $title, $html);
                }

                redirectTo('/admin/posts/index.php');
            }
        }
    }
}

$episodeOptions = $db->query('SELECT id, title FROM podcast_episodes ORDER BY created_at DESC')->fetchAll();

$pageTitle = ($post ? 'Edit Post' : 'New Post') . ' | Zibrah Code Admin';
$activeAdminNav = 'posts';
require __DIR__ . '/../includes/admin-header.php';
?>

<div x-data="{ previewMode: false }">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8 sticky top-0 bg-brand-gray-50/95 backdrop-blur py-4 z-10 -mx-6 md:-mx-12 px-6 md:px-12 border-b border-gray-200">
        <h1 class="font-display font-black text-2xl text-brand-black"><?php echo $post ? 'Edit Post' : 'New Post'; ?></h1>
        <div class="flex flex-wrap items-center gap-3">
            <div class="flex bg-white border border-gray-200">
                <button type="button" @click="previewMode = false" :class="!previewMode ? 'bg-brand-black text-white' : 'text-gray-500'" class="px-4 sm:px-5 py-2 text-xs font-bold uppercase tracking-widest transition-colors">Edit</button>
                <button type="button" @click="previewMode = true" :class="previewMode ? 'bg-brand-black text-white' : 'text-gray-500'" class="px-4 sm:px-5 py-2 text-xs font-bold uppercase tracking-widest transition-colors">Preview</button>
            </div>
            <select name="status" form="post-form" class="bg-white border border-gray-200 px-4 py-2 text-xs font-bold uppercase tracking-widest focus:outline-none focus:border-brand-gold">
                <option value="draft" <?php echo ($post['status'] ?? 'draft') === 'draft' ? 'selected' : ''; ?>>Draft</option>
                <option value="published" <?php echo ($post['status'] ?? '') === 'published' ? 'selected' : ''; ?>>Published</option>
            </select>
            <button type="submit" form="post-form" class="bg-brand-black text-white px-6 py-2.5 text-xs font-bold uppercase tracking-widest hover:bg-brand-gold transition-all">Save Post</button>
        </div>
    </div>

    <?php if ($error): ?><p class="mb-8 p-4 bg-red-50 border border-red-300 text-red-700 text-sm"><?php echo e($error); ?></p><?php endif; ?>

    <!-- EDIT VIEW -->
    <form id="post-form" method="POST" enctype="multipart/form-data" x-show="!previewMode" class="grid lg:grid-cols-3 gap-10">
        <?php echo csrfField(); ?>
        <?php if ($post): ?><input type="hidden" name="id" value="<?php echo $post['id']; ?>"><?php endif; ?>

        <div class="lg:col-span-2 space-y-6">
            <textarea name="title" id="title-input" required rows="1" placeholder="Post title&hellip;"
                class="w-full text-4xl md:text-5xl serif font-black text-brand-black placeholder-gray-300 border-0 border-b-2 border-transparent focus:border-brand-gold focus:outline-none bg-transparent pb-4 transition-colors resize-none overflow-hidden"><?php echo e($post['title'] ?? ''); ?></textarea>

            <div>
                <div id="quill-editor" style="height: 500px;" class="bg-white"></div>
                <textarea name="body" id="body-input" class="hidden"><?php echo e($post['body'] ?? ''); ?></textarea>
            </div>
        </div>

        <div class="space-y-6">
            <div>
                <label class="text-xs uppercase tracking-widest font-bold text-brand-black">Featured Image</label>
                <div class="mt-2">
                    <img id="featured-image-preview" src="<?php echo !empty($post['featured_image_path']) ? '/' . e($post['featured_image_path']) : ''; ?>" alt="Featured image preview"
                        class="w-full h-auto border border-gray-200 mb-3" style="<?php echo empty($post['featured_image_path']) ? 'display:none' : ''; ?>">
                    <input type="file" name="featured_image" id="featured-image-input" accept="image/jpeg,image/png,image/webp" class="w-full bg-gray-50 border border-gray-200 px-4 py-3 text-sm">
                </div>
            </div>
            <?php
            $presetCategories = ['Framework & Theory', 'Strategic Research', 'Leadership', 'Conflict & Mediation', 'Case Studies', 'Announcements'];
            $currentCategory = $post['category'] ?? '';
            $isPresetCategory = $currentCategory === '' || in_array($currentCategory, $presetCategories, true);
            ?>
            <div x-data="{ customCategory: <?php echo $isPresetCategory ? 'false' : 'true'; ?> }">
                <label class="text-xs uppercase tracking-widest font-bold text-brand-black">Category</label>
                <select @change="customCategory = ($event.target.value === '__other__')" :name="customCategory ? null : 'category'" x-show="!customCategory"
                    class="w-full bg-gray-50 border border-gray-200 px-4 py-3 mt-2 focus:outline-none focus:border-brand-gold">
                    <option value="">— None —</option>
                    <?php foreach ($presetCategories as $option): ?>
                        <option value="<?php echo e($option); ?>" <?php echo $currentCategory === $option ? 'selected' : ''; ?>><?php echo e($option); ?></option>
                    <?php endforeach; ?>
                    <option value="__other__" <?php echo !$isPresetCategory ? 'selected' : ''; ?>>Other…</option>
                </select>
                <div x-show="customCategory" x-cloak class="mt-2 flex gap-2">
                    <input type="text" :name="customCategory ? 'category' : null" value="<?php echo e($currentCategory); ?>" placeholder="New category name"
                        class="w-full bg-gray-50 border border-gray-200 px-4 py-3 focus:outline-none focus:border-brand-gold">
                    <button type="button" @click="customCategory = false" class="text-xs font-bold uppercase text-gray-400 hover:text-brand-black flex-shrink-0 px-2">Cancel</button>
                </div>
            </div>
            <div>
                <label class="text-xs uppercase tracking-widest font-bold text-brand-black">Linked Podcast Episode</label>
                <select name="podcast_episode_id" class="w-full bg-gray-50 border border-gray-200 px-4 py-3 mt-2 focus:outline-none focus:border-brand-gold">
                    <option value="">— None —</option>
                    <?php foreach ($episodeOptions as $option): ?>
                        <option value="<?php echo $option['id']; ?>" <?php echo (int) ($post['podcast_episode_id'] ?? 0) === (int) $option['id'] ? 'selected' : ''; ?>><?php echo e($option['title']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="text-xs uppercase tracking-widest font-bold text-brand-black">Slug <span class="font-normal normal-case text-gray-400">(auto-generated if blank)</span></label>
                <input type="text" name="slug" value="<?php echo e($post['slug'] ?? ''); ?>" class="w-full bg-gray-50 border border-gray-200 px-4 py-3 mt-2 focus:outline-none focus:border-brand-gold">
            </div>
            <div>
                <label class="text-xs uppercase tracking-widest font-bold text-brand-black">Excerpt</label>
                <textarea name="excerpt" rows="3" class="w-full bg-gray-50 border border-gray-200 px-4 py-3 mt-2 focus:outline-none focus:border-brand-gold"><?php echo e($post['excerpt'] ?? ''); ?></textarea>
            </div>
            <div>
                <div class="flex items-center justify-between">
                    <label class="text-xs uppercase tracking-widest font-bold text-brand-black">Meta Description</label>
                    <button type="button" id="generate-meta-btn" class="text-[10px] font-bold uppercase tracking-widest text-brand-gold hover:text-brand-black transition-colors">✦ Generate with AI</button>
                </div>
                <input type="text" name="meta_description" id="meta-description-input" maxlength="300" value="<?php echo e($post['meta_description'] ?? ''); ?>" class="w-full bg-gray-50 border border-gray-200 px-4 py-3 mt-2 focus:outline-none focus:border-brand-gold">
                <p id="generate-meta-error" class="text-xs text-red-500 mt-2 hidden"></p>
            </div>
        </div>
    </form>

    <!-- PREVIEW VIEW — mirrors post.php's real markup so this matches the live page -->
    <div x-show="previewMode" x-cloak class="bg-white border border-gray-100 max-w-4xl mx-auto">
        <div class="p-6 sm:p-10 md:p-20">
            <img id="preview-image" src="<?php echo !empty($post['featured_image_path']) ? '/' . e($post['featured_image_path']) : ''; ?>" alt="<?php echo e($post['title'] ?? ''); ?>"
                class="w-full h-auto mb-12 shadow-2xl" style="<?php echo empty($post['featured_image_path']) ? 'display:none' : ''; ?>">
            <h1 id="preview-title" class="text-4xl md:text-6xl serif font-black text-brand-black tracking-tight mb-10"><?php echo e($post['title'] ?? 'Post title…'); ?></h1>
            <div id="preview-body" class="article-body drop-cap serif text-2xl text-brand-gray-700 leading-relaxed space-y-8"><?php echo $post['body'] ?? ''; ?></div>
        </div>
    </div>
</div>

<link href="https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.snow.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.js"></script>
<script>
    const quill = new Quill('#quill-editor', {
        theme: 'snow',
        modules: {
            toolbar: [
                [{ header: [2, 3, false] }],
                ['bold', 'italic', 'underline'],
                ['blockquote', 'link'],
                [{ list: 'ordered' }, { list: 'bullet' }],
                ['image'],
                ['clean'],
            ],
        },
    });
    const bodyInput = document.getElementById('body-input');
    const titleInput = document.getElementById('title-input');
    const previewTitle = document.getElementById('preview-title');
    const previewBody = document.getElementById('preview-body');
    const featuredImageInput = document.getElementById('featured-image-input');
    const featuredImagePreview = document.getElementById('featured-image-preview');
    const previewImage = document.getElementById('preview-image');

    quill.root.innerHTML = bodyInput.value;

    function syncPreview() {
        bodyInput.value = quill.root.innerHTML;
        previewBody.innerHTML = quill.root.innerHTML;
        previewTitle.textContent = titleInput.value || 'Post title…';
    }
    function autoGrowTitle() {
        titleInput.style.height = 'auto';
        titleInput.style.height = titleInput.scrollHeight + 'px';
    }
    quill.on('text-change', syncPreview);
    titleInput.addEventListener('input', () => { autoGrowTitle(); syncPreview(); });
    document.getElementById('post-form').addEventListener('submit', syncPreview);
    autoGrowTitle();

    featuredImageInput.addEventListener('change', () => {
        if (featuredImageInput.files && featuredImageInput.files[0]) {
            const objectUrl = URL.createObjectURL(featuredImageInput.files[0]);
            featuredImagePreview.src = objectUrl;
            featuredImagePreview.style.display = '';
            previewImage.src = objectUrl;
            previewImage.style.display = '';
        }
    });

    // Custom image handler: upload the file, then insert it at the cursor
    // instead of Quill's default "paste an image URL" prompt.
    quill.getModule('toolbar').addHandler('image', () => {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/jpeg,image/png,image/webp');
        input.click();
        input.onchange = async () => {
            const file = input.files[0];
            if (!file) return;
            const formData = new FormData();
            formData.append('image', file);
            formData.append('csrf_token', document.querySelector('meta[name="csrf-token"]').content);
            const range = quill.getSelection(true);
            try {
                const response = await fetch('/admin/posts/upload-image', { method: 'POST', body: formData });
                const data = await response.json();
                if (data.url) {
                    quill.insertEmbed(range.index, 'image', data.url);
                    quill.setSelection(range.index + 1);
                } else {
                    alert(data.error || 'Image upload failed.');
                }
            } catch (e) {
                alert('Image upload failed — please try again.');
            }
        };
    });

    document.getElementById('generate-meta-btn').addEventListener('click', async function () {
        const btn = this;
        const errorEl = document.getElementById('generate-meta-error');
        const metaInput = document.getElementById('meta-description-input');
        const title = titleInput.value.trim();
        const body = quill.getText().trim() || document.querySelector('textarea[name="excerpt"]').value.trim();

        errorEl.classList.add('hidden');
        if (!title) {
            errorEl.textContent = 'Add a title first.';
            errorEl.classList.remove('hidden');
            return;
        }

        const originalText = btn.textContent;
        btn.textContent = 'Generating…';
        btn.disabled = true;

        try {
            const formData = new FormData();
            formData.append('title', title);
            formData.append('body', body);
            formData.append('csrf_token', document.querySelector('meta[name="csrf-token"]').content);
            const response = await fetch('/admin/posts/generate-meta', { method: 'POST', body: formData });
            const data = await response.json();
            if (data.description) {
                metaInput.value = data.description;
            } else {
                errorEl.textContent = data.error || 'Could not generate a description.';
                errorEl.classList.remove('hidden');
            }
        } catch (e) {
            errorEl.textContent = 'Could not reach the AI service — please try again.';
            errorEl.classList.remove('hidden');
        } finally {
            btn.textContent = originalText;
            btn.disabled = false;
        }
    });
</script>

<?php require __DIR__ . '/../includes/admin-footer.php'; ?>
